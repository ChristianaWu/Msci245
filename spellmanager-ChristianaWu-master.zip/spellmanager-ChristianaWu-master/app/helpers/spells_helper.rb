module SpellsHelper
end
